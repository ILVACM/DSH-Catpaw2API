# DSH-Catpaw2API
将美团catpaw（妙手）接入DSH使用（注意自备账号）

把妙手客户端额度与 LongCat 官方 API 接进 DSH 的双通道插件。
阶段一状态：通道 A 可用（模型列表/参数取自官方 `/v1/models` 与 `/v1/models/{model}`，不显示官方余额——需查余额请自行去官网），通道 B 为占位（P1 placeholder）。
隐私声明：所有数据只留本机，插件不上传、不遥测、不代管；本仓库不含任何真实账号、令牌或路径。

